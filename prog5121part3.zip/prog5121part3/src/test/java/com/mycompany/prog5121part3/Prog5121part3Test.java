/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.prog5121part3;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class Prog5121part3Test {

    private ArrayList<String> sentMessages;
    private ArrayList<String> storedMessages;
    private ArrayList<String> disregardedMessages;
    private ArrayList<String> messageIDs;
    private ArrayList<String> messageHashes;
    private ArrayList<String> allRecipients;
    private ArrayList<String> allStatuses;

    @BeforeEach
    public void setUp() {
        sentMessages = new ArrayList<>();
        storedMessages = new ArrayList<>();
        disregardedMessages = new ArrayList<>();
        messageIDs = new ArrayList<>();
        messageHashes = new ArrayList<>();
        allRecipients = new ArrayList<>();
        allStatuses = new ArrayList<>();

        // Test Data Message 1: Sent
        addTestMessage("1000000001", "10:1:DIDCAKE?", "+27834557896", "Did you get the cake?", "Sent");

        // Test Data Message 2: Stored
        addTestMessage("1000000002", "10:2:WHERETIME.", "+27838884567", "Where are you? You are late! I have asked you to be on time.", "Stored");

        // Test Data Message 3: Disregarded
        addTestMessage("1000000003", "10:3:YOHOOOOGATE.", "+27834484567", "Yohoooo, I am at your gate.", "Disregard");

        // Test Data Message 4: Sent (Developer / Message ID 0838884567 per rubric test case)
        addTestMessage("0838884567", "08:4:IT!", "0838884567", "It is dinner time !", "Sent");

        // Test Data Message 5: Stored
        addTestMessage("1000000005", "10:5:OK,YOU.", "+27838884567", "Ok, I am leaving without you.", "Stored");
    }

    private void addTestMessage(String id, String hash, String recipient, String text, String flag) {
        switch (flag) {
            case "Sent" -> {
                sentMessages.add(text);
                messageIDs.add(id);
                messageHashes.add(hash);
                allRecipients.add(recipient);
                allStatuses.add("Sent");
            }
            case "Stored" -> {
                storedMessages.add(text);
                messageIDs.add(id);
                messageHashes.add(hash);
                allRecipients.add(recipient);
                allStatuses.add("Stored");
            }
            case "Disregard" -> disregardedMessages.add(text);
        }
    }

    private String resolveMessageText(int index) {
        String status = allStatuses.get(index);
        int count = 0;
        for (int j = 0; j < index; j++) {
            if (allStatuses.get(j).equals(status)) {
                count++;
            }
        }
        return "Sent".equals(status) ? sentMessages.get(count) : storedMessages.get(count);
    }

    // 1. Sent Messages array correctly populated[cite: 19]
    @Test
    public void testSentMessagesArrayPopulated() {
        List<String> expected = Arrays.asList("Did you get the cake?", "It is dinner time !");
        assertEquals(expected, sentMessages);
    }

    // 2. Display the longest Message (Test Data 1-4)[cite: 19]
    @Test
    public void testDisplayLongestMessage() {
        ArrayList<String> combined = new ArrayList<>();
        combined.addAll(sentMessages);
        combined.addAll(storedMessages);

        String longest = "";
        for (String msg : combined) {
            if (msg.length() > longest.length()) {
                longest = msg;
            }
        }

        assertEquals("Where are you? You are late! I have asked you to be on time.", longest);
    }

    // 3. Search for messageID ("0838884567")[cite: 19]
    @Test
    public void testSearchForMessageID() {
        String searchId = "0838884567";
        String foundMessage = "";

        for (int i = 0; i < messageIDs.size(); i++) {
            if (messageIDs.get(i).equals(searchId)) {
                foundMessage = resolveMessageText(i);
                break;
            }
        }

        assertEquals("It is dinner time !", foundMessage);
    }

    // 4. Search all messages sent or stored regarding a particular recipient (+27838884567)[cite: 19]
    @Test
    public void testSearchMessagesByRecipient() {
        String targetRecipient = "+27838884567";
        List<String> matchingMessages = new ArrayList<>();

        for (int i = 0; i < allRecipients.size(); i++) {
            if (allRecipients.get(i).equals(targetRecipient)) {
                matchingMessages.add(resolveMessageText(i));
            }
        }

        List<String> expected = Arrays.asList(
                "Where are you? You are late! I have asked you to be on time.",
                "Ok, I am leaving without you."
        );
        assertEquals(expected, matchingMessages);
    }

    // 5. Delete a message using a message hash (Test Message 2)[cite: 19]
    @Test
    public void testDeleteMessageUsingHash() {
        String targetHash = "10:2:WHERETIME.";
        String confirmation = "";

        for (int i = 0; i < messageHashes.size(); i++) {
            if (messageHashes.get(i).equals(targetHash)) {
                String deletedText = resolveMessageText(i);
                sentMessages.remove(deletedText);
                storedMessages.remove(deletedText);
                messageIDs.remove(i);
                messageHashes.remove(i);
                allRecipients.remove(i);
                allStatuses.remove(i);

                confirmation = "Message: \"" + deletedText + "\" successfully deleted.";
                break;
            }
        }

        assertEquals("Message: \"Where are you? You are late! I have asked you to be on time.\" successfully deleted.", confirmation);
    }

    // 6. Display Report (includes Message Hash, Recipient, Message)[cite: 19]
    @Test
    public void testDisplayReport() {
        StringBuilder report = new StringBuilder();
        for (int i = 0; i < messageIDs.size(); i++) {
            if ("Sent".equals(allStatuses.get(i))) {
                report.append("Message Hash: ").append(messageHashes.get(i)).append("\n")
                      .append("Recipient: ").append(allRecipients.get(i)).append("\n")
                      .append("Message: ").append(resolveMessageText(i)).append("\n");
            }
        }

        String reportOutput = report.toString();
        assertTrue(reportOutput.contains("Message Hash: 10:1:DIDCAKE?"));
        assertTrue(reportOutput.contains("Recipient: +27834557896"));
        assertTrue(reportOutput.contains("Message: Did you get the cake?"));
        assertTrue(reportOutput.contains("Message Hash: 08:4:IT!"));
        assertTrue(reportOutput.contains("Recipient: 0838884567"));
        assertTrue(reportOutput.contains("Message: It is dinner time !"));
    }
}